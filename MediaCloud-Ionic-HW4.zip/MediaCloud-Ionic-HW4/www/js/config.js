angular.module('mc.config', [])
  .constant('MC_API_INFO', {
    apiKey: 'replace API_KEY again'
  });
